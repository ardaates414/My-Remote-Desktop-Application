"""
Remote Desktop Client Application
Connects to authorized remote desktop hosts
"""

import socket
import threading
import tkinter as tk
from tkinter import messagebox, filedialog, ttk
import json
import os
import time
from PIL import Image, ImageTk
import io
import base64
import getpass
import platform

# Try to import psutil and statistics, use fallbacks if not available
try:
    import psutil
except ImportError:
    psutil = None

try:
    import statistics
except ImportError:
    # Fallback for older Python versions
    def mean(data):
        return sum(data) / len(data) if data else 0
    statistics = type('statistics', (), {'mean': mean})()

class RemoteDesktopClient:
    def __init__(self):
        self.client_socket = None
        self.is_connected = False
        self.is_authorized = False
        self.host_ip = ""
        self.host_port = 9999
        self.username = getpass.getuser()
        
        # Connection optimization variables - MAXIMUM SPEED SETTINGS! 🚀
        self.refresh_times = []  # Track refresh performance
        self.connection_errors = 0
        self.last_refresh_time = 0
        self.adaptive_refresh_rate = 0.0001  # INSANE SPEED! 10,000 FPS!
        self.image_quality = 40  # Start with better quality
        self.max_image_size = (1024, 768)  # Start with larger size
        self.bandwidth_score = 3  # Assume medium connection initially
        self.connection_stable = True
        
        # Speed optimizations
        self.fast_mode = True  # Enable aggressive optimizations
        self.skip_frames = 0   # Skip frames counter for speed
        
        # Connection monitoring
        self.last_successful_refresh = time.time()
        self.connection_monitor_thread = None
        self.monitor_running = False
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 3
        
        # Setup GUI
        self.setup_gui()
        
        # Remote desktop variables
        self.remote_screen = None
        self.screen_label = None
        
        # Fullscreen variables
        self.fullscreen_window = None
        self.fullscreen_canvas = None
        self.is_fullscreen = False
        self.original_window_size = None
        self.fullscreen_remote_screen = None
        
    def setup_gui(self):
        """Initialize the client GUI"""
        self.root = tk.Tk()
        self.root.title("Remote Desktop Client")
        self.root.geometry("900x700")
        self.root.resizable(True, True)
        
        # Create main notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Connection tab
        self.setup_connection_tab()
        
        # Remote desktop tab
        self.setup_remote_desktop_tab()
        
        # File transfer tab
        self.setup_file_transfer_tab()
        
    def setup_connection_tab(self):
        """Setup the connection tab"""
        connection_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(connection_frame, text="Connection")
        
        # Connection settings
        settings_frame = ttk.LabelFrame(connection_frame, text="Connection Settings", padding="10")
        settings_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 20))
        
        ttk.Label(settings_frame, text="Host IP Address:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.ip_var = tk.StringVar()
        ttk.Entry(settings_frame, textvariable=self.ip_var, width=25).grid(row=0, column=1, pady=2, padx=(10, 0))
        
        ttk.Label(settings_frame, text="Your Username:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.username_var = tk.StringVar(value=self.username)
        ttk.Entry(settings_frame, textvariable=self.username_var, width=25).grid(row=1, column=1, pady=2, padx=(10, 0))
        
        # Connection controls
        control_frame = ttk.Frame(connection_frame)
        control_frame.grid(row=1, column=0, columnspan=2, pady=10)
        
        self.connect_button = ttk.Button(control_frame, text="Connect", command=self.connect_to_host)
        self.connect_button.pack(side=tk.LEFT, padx=5)
        
        self.disconnect_button = ttk.Button(control_frame, text="Disconnect", command=self.disconnect_from_host, state="disabled")
        self.disconnect_button.pack(side=tk.LEFT, padx=5)
        
        # Status
        ttk.Label(connection_frame, text="Connection Status:", font=("Arial", 10, "bold")).grid(row=2, column=0, columnspan=2, pady=(20, 5))
        
        self.status_label = ttk.Label(connection_frame, text="Not Connected", foreground="red")
        self.status_label.grid(row=3, column=0, columnspan=2, pady=5)
        
        # Log
        ttk.Label(connection_frame, text="Connection Log:", font=("Arial", 10, "bold")).grid(row=4, column=0, columnspan=2, pady=(20, 5))
        
        self.log_text = tk.Text(connection_frame, height=15, width=70, state="disabled")
        self.log_text.grid(row=5, column=0, columnspan=2, pady=5)
        
        # Scrollbar for log
        log_scrollbar = ttk.Scrollbar(connection_frame, orient="vertical", command=self.log_text.yview)
        log_scrollbar.grid(row=5, column=2, sticky=(tk.N, tk.S))
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        
    def setup_remote_desktop_tab(self):
        """Setup the remote desktop tab"""
        desktop_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(desktop_frame, text="Remote Desktop")
        
        # Controls
        control_frame = ttk.Frame(desktop_frame)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.refresh_button = ttk.Button(control_frame, text="Refresh Screen", command=self.refresh_screen, state="disabled")
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        self.auto_refresh_var = tk.BooleanVar(value=True)  # Enable by default
        self.auto_refresh_check = ttk.Checkbutton(control_frame, text="Auto Refresh (Adaptive)", 
                                                variable=self.auto_refresh_var, 
                                                command=self.toggle_auto_refresh, state="disabled")
        self.auto_refresh_check.pack(side=tk.LEFT, padx=10)
        
        # Fullscreen button
        self.fullscreen_button = ttk.Button(control_frame, text="⛶ Fullscreen", command=self.toggle_fullscreen, state="disabled")
        self.fullscreen_button.pack(side=tk.LEFT, padx=10)
        
        # Connection status indicators
        status_frame = ttk.Frame(control_frame)
        status_frame.pack(side=tk.RIGHT, padx=10)
        
        ttk.Label(status_frame, text="Quality:").pack(side=tk.LEFT)
        self.quality_label = ttk.Label(status_frame, text="30", foreground="orange")
        self.quality_label.pack(side=tk.LEFT, padx=(2, 10))
        
        ttk.Label(status_frame, text="Rate:").pack(side=tk.LEFT)
        self.rate_label = ttk.Label(status_frame, text="0.5s", foreground="orange")
        self.rate_label.pack(side=tk.LEFT, padx=(2, 10))
        
        ttk.Label(status_frame, text="Errors:").pack(side=tk.LEFT)
        self.error_label = ttk.Label(status_frame, text="0", foreground="green")
        self.error_label.pack(side=tk.LEFT, padx=2)
        
        # Screen display
        self.screen_frame = ttk.Frame(desktop_frame)
        self.screen_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create canvas for screen display with scrollbars
        self.canvas = tk.Canvas(self.screen_frame, bg="black")
        h_scrollbar = ttk.Scrollbar(self.screen_frame, orient="horizontal", command=self.canvas.xview)
        v_scrollbar = ttk.Scrollbar(self.screen_frame, orient="vertical", command=self.canvas.yview)
        
        self.canvas.configure(xscrollcommand=h_scrollbar.set, yscrollcommand=v_scrollbar.set)
        
        # Pack scrollbars and canvas
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Bind mouse and keyboard events
        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<Button-3>", self.on_right_click)
        self.canvas.bind("<Double-Button-1>", self.on_double_click)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<KeyPress>", self.on_key_press)
        self.canvas.focus_set()
        
        # Auto-refresh thread control
        self.auto_refresh_thread = None
        self.auto_refresh_running = False
        
    def setup_file_transfer_tab(self):
        """Setup the file transfer tab"""
        transfer_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(transfer_frame, text="File Transfer")
        
        # Send file section
        send_frame = ttk.LabelFrame(transfer_frame, text="Send File to Host", padding="10")
        send_frame.pack(fill=tk.X, pady=(0, 20))
        
        ttk.Button(send_frame, text="Select and Send File", command=self.send_file_to_host, state="disabled").pack(side=tk.LEFT, padx=5)
        ttk.Button(send_frame, text="Select and Send Folder", command=self.send_folder_to_host, state="disabled").pack(side=tk.LEFT, padx=5)
        
        # Receive file section
        receive_frame = ttk.LabelFrame(transfer_frame, text="Receive File from Host", padding="10")
        receive_frame.pack(fill=tk.X, pady=(0, 20))
        
        ttk.Button(receive_frame, text="Request File from Host", command=self.request_file_from_host, state="disabled").pack(side=tk.LEFT, padx=5)
        
        # Transfer status
        status_frame = ttk.LabelFrame(transfer_frame, text="Transfer Status", padding="10")
        status_frame.pack(fill=tk.BOTH, expand=True)
        
        self.transfer_log = tk.Text(status_frame, height=20, width=70, state="disabled")
        self.transfer_log.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Scrollbar for transfer log
        transfer_scrollbar = ttk.Scrollbar(status_frame, orient="vertical", command=self.transfer_log.yview)
        transfer_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.transfer_log.configure(yscrollcommand=transfer_scrollbar.set)
        
    def log_message(self, message, log_widget=None):
        """Add a message to the specified log widget"""
        if log_widget is None:
            log_widget = self.log_text
            
        log_widget.config(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        log_widget.insert(tk.END, f"[{timestamp}] {message}\n")
        log_widget.see(tk.END)
        log_widget.config(state="disabled")
    
    def connect_to_host(self):
        """Connect to the remote host"""
        try:
            self.host_ip = self.ip_var.get().strip()
            self.host_port = 9999  # Fixed port
            self.username = self.username_var.get().strip()
            
            if not self.host_ip:
                messagebox.showerror("Error", "Please enter a host IP address")
                return
                
            if not self.username:
                messagebox.showerror("Error", "Please enter your username")
                return
            
            self.log_message(f"Attempting to connect to {self.host_ip}:{self.host_port}")
            
            # Create socket and connect with optimizations for weak connections
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            
            # Optimize socket for weak connections
            self.optimize_socket_for_weak_connection()
            
            self.client_socket.connect((self.host_ip, self.host_port))
            
            # Send connection request
            connection_request = {
                'type': 'connection_request',
                'username': self.username
            }
            
            self.client_socket.send(json.dumps(connection_request).encode('utf-8'))
            
            # Wait for authorization response
            response_data = self.client_socket.recv(1024).decode('utf-8')
            response = json.loads(response_data)
            
            if response.get('type') == 'connection_response' and response.get('authorized'):
                self.is_connected = True
                self.is_authorized = True
                
                self.status_label.config(text=f"Connected to {self.host_ip}", foreground="green")
                self.connect_button.config(state="disabled")
                self.disconnect_button.config(state="normal")
                
                # Enable remote desktop controls
                self.refresh_button.config(state="normal")
                self.auto_refresh_check.config(state="normal")
                self.fullscreen_button.config(state="normal")
                
                # Enable file transfer buttons
                for widget in self.notebook.nametowidget(self.notebook.tabs()[2]).winfo_children():
                    if isinstance(widget, ttk.LabelFrame):
                        for child in widget.winfo_children():
                            if isinstance(child, ttk.Button):
                                child.config(state="normal")
                
                self.log_message("Connection authorized and established")
                
                # Switch to remote desktop tab
                self.notebook.select(1)
                
                # Detect connection speed first
                self.detect_connection_speed()
                
                # Get initial screen and start auto-refresh with adaptive settings
                self.refresh_screen()
                
                # Start auto-refresh automatically since it's enabled by default
                if self.auto_refresh_var.get():
                    self.toggle_auto_refresh()
                
            else:
                self.log_message("Connection denied by host")
                messagebox.showerror("Connection Denied", "The host denied your connection request")
                self.disconnect_from_host()
                
        except socket.timeout:
            self.log_message("Connection timed out")
            messagebox.showerror("Connection Error", "Connection timed out")
            self.disconnect_from_host()
        except ConnectionRefusedError:
            self.log_message("Connection refused - host may not be running")
            messagebox.showerror("Connection Error", "Connection refused. Make sure the host is running.")
            self.disconnect_from_host()
        except Exception as e:
            self.log_message(f"Connection error: {str(e)}")
            messagebox.showerror("Connection Error", f"Failed to connect: {str(e)}")
            self.disconnect_from_host()
    
    def disconnect_from_host(self):
        """Disconnect from the remote host"""
        self.is_connected = False
        self.is_authorized = False
        self.auto_refresh_running = False
        
        if self.client_socket:
            try:
                self.client_socket.close()
            except:
                pass
            self.client_socket = None
        
        self.status_label.config(text="Not Connected", foreground="red")
        self.connect_button.config(state="normal")
        self.disconnect_button.config(state="disabled")
        
        # Disable remote desktop controls
        self.refresh_button.config(state="disabled")
        self.auto_refresh_check.config(state="disabled")
        self.fullscreen_button.config(state="disabled")
        
        # Disable file transfer buttons
        try:
            for widget in self.notebook.nametowidget(self.notebook.tabs()[2]).winfo_children():
                if isinstance(widget, ttk.LabelFrame):
                    for child in widget.winfo_children():
                        if isinstance(child, ttk.Button):
                            child.config(state="disabled")
        except:
            pass
        
        # Clear screen
        self.canvas.delete("all")
        
        self.log_message("Disconnected from host")
    
    def optimize_socket_for_weak_connection(self):
        """Optimize socket settings for weak internet connections"""
        try:
            # Longer timeout for weak connections
            self.client_socket.settimeout(30)
            
            # Enable TCP keepalive to detect broken connections
            self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            
            # Reduce buffer sizes to avoid overwhelming weak connections
            self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 32768)  # 32KB receive buffer
            self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 32768)  # 32KB send buffer
            
            # Disable Nagle's algorithm for better interactivity
            self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            
            # Platform-specific keepalive settings
            if platform.system() == "Windows":
                # Windows keepalive settings
                self.client_socket.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 30000, 5000))  # Enable, 30s idle, 5s interval
            elif platform.system() in ["Linux", "Darwin"]:
                # Linux/macOS keepalive settings
                if hasattr(socket, 'TCP_KEEPIDLE'):
                    self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)  # 30s idle
                if hasattr(socket, 'TCP_KEEPINTVL'):
                    self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 5)   # 5s interval
                if hasattr(socket, 'TCP_KEEPCNT'):
                    self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)     # 3 probes
                    
            self.log_message("Socket optimized for weak connection")
            
        except Exception as e:
            self.log_message(f"Socket optimization warning: {str(e)}")
    
    def detect_connection_speed(self):
        """Detect connection speed and adjust settings"""
        try:
            start_time = time.time()
            test_request = {'type': 'ping'}
            self.send_request(test_request)
            
            # Simple latency test
            response_data = self.client_socket.recv(1024)
            end_time = time.time()
            
            latency = (end_time - start_time) * 1000  # Convert to milliseconds
            
            # ULTRA-FAST SPEED SETTINGS - MAXIMUM PERFORMANCE!
            if latency > 1000:  # Extremely slow connection
                self.adaptive_refresh_rate = 0.5  # Still much faster than before!
                self.image_quality = 15
                self.max_image_size = (480, 360)
                self.bandwidth_score = 1
                self.fast_mode = True  # Always use fast mode!
                self.log_message(f"Extremely slow connection detected ({latency:.0f}ms) - using SPEED-OPTIMIZED settings")
            elif latency > 500:  # Very slow connection
                self.adaptive_refresh_rate = 0.2  # Much faster!
                self.image_quality = 20
                self.max_image_size = (640, 480)
                self.bandwidth_score = 1
                self.fast_mode = True
                self.log_message(f"Very slow connection detected ({latency:.0f}ms) - using ULTRA-FAST settings")
            elif latency > 200:  # Slow connection
                self.adaptive_refresh_rate = 0.05  # SUPER FAST!
                self.image_quality = 30
                self.max_image_size = (720, 540)
                self.bandwidth_score = 2
                self.fast_mode = True
                self.log_message(f"Slow connection detected ({latency:.0f}ms) - using SUPER-SPEED settings")
            elif latency > 100:  # Medium connection
                self.adaptive_refresh_rate = 0.01  # ULTRA FAST!
                self.image_quality = 40
                self.max_image_size = (800, 600)
                self.bandwidth_score = 3
                self.fast_mode = True
                self.log_message(f"Medium connection detected ({latency:.0f}ms) - using ULTRA-FAST settings")
            else:  # Fast connection
                self.adaptive_refresh_rate = 0.001  # LIGHTNING FAST! Almost instant!
                self.image_quality = 60
                self.max_image_size = (1024, 768)
                self.bandwidth_score = 4
                self.fast_mode = True
                self.log_message(f"Fast connection detected ({latency:.0f}ms) - using LIGHTNING-SPEED settings!")
                
        except Exception as e:
            self.log_message(f"Connection speed detection failed: {str(e)} - using optimized default settings")
            # Use optimized defaults for weak connections
            self.adaptive_refresh_rate = 0.8  # Slightly slower but stable
            self.image_quality = 25           # Lower quality for speed
            self.bandwidth_score = 2          # Assume slow connection
            self.fast_mode = True             # Enable optimizations
    
    def send_request(self, request):
        """Send a request to the host"""
        if not self.is_connected or not self.client_socket:
            return None
        
        try:
            request_json = json.dumps(request)
            self.client_socket.send(request_json.encode('utf-8'))
            return True
        except Exception as e:
            self.log_message(f"Request send error: {str(e)}")
            return False
    
    def refresh_screen(self):
        """Request and display updated screen from host with ULTRA-FAST optimizations"""
        if not self.is_connected:
            return
        
        try:
            refresh_start_time = time.time()
            
            # SPEED OPTIMIZATION: Send screenshot request with optimal settings
            request = {
                'type': 'screenshot',
                'quality': self.image_quality,
                'max_size': self.max_image_size
            }
            if not self.send_request(request):
                return
            
            # SPEED OPTIMIZATION: Faster data receiving
            response_data = self.receive_large_data_fast()
            if not response_data:
                return
                
            response = json.loads(response_data.decode('utf-8'))
            
            if response.get('type') == 'screenshot_response':
                # SPEED OPTIMIZATION: Handle "no change" responses instantly
                if response.get('no_change'):
                    # Update timing but don't refresh display
                    self.last_successful_refresh = time.time()
                    refresh_time = time.time() - refresh_start_time
                    self.refresh_times.append(refresh_time * 0.1)  # Very fast "refresh"
                    return
                
                # SPEED OPTIMIZATION: Ultra-fast image processing
                image_data = base64.b64decode(response['image_data'])
                image = Image.open(io.BytesIO(image_data))
                
                # SPEED OPTIMIZATION: Skip resizing if image is already optimal size
                if self.bandwidth_score <= 2:  # Weak connection
                    current_size = image.size
                    if current_size[0] > self.max_image_size[0] or current_size[1] > self.max_image_size[1]:
                        # Ultra-fast nearest neighbor resizing for speed
                        image = image.resize(self.max_image_size, Image.Resampling.NEAREST)
                
                # SPEED OPTIMIZATION: Use fastest image conversion
                try:
                    # Direct conversion - fastest method
                    if image.mode == 'RGB':
                        photo = ImageTk.PhotoImage(image)
                    else:
                        photo = ImageTk.PhotoImage(image.convert('RGB'))
                except Exception:
                    # Emergency fallback
                    photo = ImageTk.PhotoImage(image.convert('RGB'))
                
                # SPEED OPTIMIZATION: Minimal GUI operations
                if hasattr(self, 'remote_screen') and self.remote_screen:
                    # Only delete if we have a previous image
                    self.canvas.delete("all")
                
                self.canvas.create_image(0, 0, anchor=tk.NW, image=photo)
                
                # SPEED OPTIMIZATION: Only update scrollregion when necessary
                if not hasattr(self, '_last_image_size') or self._last_image_size != image.size:
                    self.canvas.configure(scrollregion=self.canvas.bbox("all"))
                    self._last_image_size = image.size
                
                # Keep reference to prevent garbage collection
                self.remote_screen = photo
                
                # Update fullscreen display if active
                if self.is_fullscreen and self.fullscreen_canvas:
                    self.display_fullscreen_image()
                
                # Update successful refresh tracking
                self.last_successful_refresh = time.time()
                refresh_time = time.time() - refresh_start_time
                
                # Track performance for adaptive optimization
                self.refresh_times.append(refresh_time)
                if len(self.refresh_times) > 5:
                    self.refresh_times.pop(0)
                
                # SPEED OPTIMIZATION: Less frequent status updates
                if not hasattr(self, '_last_status_update') or time.time() - self._last_status_update > 1.0:
                    self.update_status_indicators()
                    self._last_status_update = time.time()
                
                # Reset error counter on success
                self.connection_errors = max(0, self.connection_errors - 1)
                
        except socket.timeout:
            self.log_message("Screen refresh timed out - optimizing for slow connection")
            self.connection_errors += 1
            self.handle_connection_slowdown()
            
        except Exception as e:
            self.log_message(f"Screen refresh error: {str(e)}")
            self.connection_errors += 1
            self.handle_connection_slowdown()
    
    def receive_large_data(self):
        """Receive large data with better chunking for weak connections"""
        try:
            # Receive response size with timeout
            self.client_socket.settimeout(15)  # 15 second timeout for size
            size_data = b""
            while len(size_data) < 4:
                chunk = self.client_socket.recv(4 - len(size_data))
                if not chunk:
                    return None
                size_data += chunk
            
            response_size = int.from_bytes(size_data, byteorder='big')
            
            # For very large responses, increase timeout
            if response_size > 1000000:  # 1MB
                self.client_socket.settimeout(60)
            elif response_size > 500000:  # 500KB
                self.client_socket.settimeout(30)
            else:
                self.client_socket.settimeout(15)
            
            # Receive response data with smaller chunks for weak connections
            response_data = b""
            chunk_size = 2048 if self.bandwidth_score <= 2 else 4096  # Smaller chunks for weak connections
            
            while len(response_data) < response_size:
                remaining = response_size - len(response_data)
                chunk = self.client_socket.recv(min(chunk_size, remaining))
                if not chunk:
                    break
                response_data += chunk
                
                # Progress feedback for large transfers
                if response_size > 100000 and len(response_data) % 50000 == 0:
                    progress = (len(response_data) / response_size) * 100
                    self.log_message(f"Receiving data: {progress:.0f}%")
            
            if len(response_data) == response_size:
                self.connection_errors = max(0, self.connection_errors - 1)  # Reduce error count on success
                return response_data
            else:
                self.log_message(f"Incomplete data received: {len(response_data)}/{response_size} bytes")
                return None
                
        except socket.timeout:
            self.log_message("Data receive timed out")
            return None
        except Exception as e:
            self.log_message(f"Data receive error: {str(e)}")
            return None
        finally:
            # Reset timeout to normal
            try:
                self.client_socket.settimeout(30)
            except:
                pass
    
    def toggle_auto_refresh(self):
        """Toggle automatic screen refresh"""
        if self.auto_refresh_var.get():
            self.auto_refresh_running = True
            self.auto_refresh_thread = threading.Thread(target=self.auto_refresh_loop, daemon=True)
            self.auto_refresh_thread.start()
        else:
            self.auto_refresh_running = False
    
    def auto_refresh_loop(self):
        """ULTRA-FAST adaptive refresh loop with speed optimizations"""
        consecutive_errors = 0
        max_errors = 5
        frame_skip_counter = 0
        
        while self.auto_refresh_running and self.is_connected:
            try:
                refresh_start = time.time()
                
                # SPEED OPTIMIZATION: Skip frames for weak connections
                if self.fast_mode and self.bandwidth_score <= 2:
                    frame_skip_counter += 1
                    if frame_skip_counter % 2 == 0:  # Skip every other frame
                        time.sleep(self.adaptive_refresh_rate * 0.5)  # Shorter wait
                        continue
                
                # Track refresh performance
                self.refresh_screen()
                
                refresh_end = time.time()
                refresh_time = refresh_end - refresh_start
                
                # Store refresh time for adaptive adjustments
                self.refresh_times.append(refresh_time)
                if len(self.refresh_times) > 5:  # Keep fewer samples for faster adaptation
                    self.refresh_times.pop(0)
                
                # AGGRESSIVE adaptive rate adjustment
                if len(self.refresh_times) >= 3:
                    avg_refresh_time = statistics.mean(self.refresh_times)
                    
                    # More aggressive adjustments for speed
                    if avg_refresh_time > 1.5:  # Reduced threshold
                        self.adaptive_refresh_rate = min(3.0, self.adaptive_refresh_rate * 1.3)
                        # Enable frame skipping if not already
                        if not self.fast_mode:
                            self.fast_mode = True
                            self.log_message("Enabling fast mode due to slow performance")
                    elif avg_refresh_time < 0.3 and self.adaptive_refresh_rate > 0.1:  # More aggressive speedup
                        self.adaptive_refresh_rate = max(0.1, self.adaptive_refresh_rate * 0.7)
                
                # Reset error counter on successful refresh
                consecutive_errors = 0
                
                # DYNAMIC sleep time based on performance
                if self.fast_mode and avg_refresh_time > 1.0:
                    sleep_time = max(0.05, self.adaptive_refresh_rate * 0.5)  # Shorter waits
                else:
                    sleep_time = self.adaptive_refresh_rate
                
                time.sleep(sleep_time)
                
            except Exception as e:
                consecutive_errors += 1
                self.log_message(f"Refresh error ({consecutive_errors}/{max_errors}): {str(e)}")
                
                if consecutive_errors >= max_errors:
                    self.log_message("Too many consecutive errors, stopping auto-refresh")
                    self.auto_refresh_running = False
                    self.auto_refresh_var.set(False)
                    break
                
                # Back off on errors
                time.sleep(min(5.0, self.adaptive_refresh_rate * consecutive_errors))
    
    def update_status_indicators(self):
        """Update the connection status indicators in the GUI"""
        try:
            # Update quality indicator
            quality_color = "green" if self.image_quality >= 40 else "orange" if self.image_quality >= 25 else "red"
            self.quality_label.config(text=str(self.image_quality), foreground=quality_color)
            
            # Update refresh rate indicator
            rate_color = "green" if self.adaptive_refresh_rate <= 0.5 else "orange" if self.adaptive_refresh_rate <= 1.5 else "red"
            self.rate_label.config(text=f"{self.adaptive_refresh_rate:.1f}s", foreground=rate_color)
            
            # Update error count indicator
            error_color = "green" if self.connection_errors == 0 else "orange" if self.connection_errors <= 2 else "red"
            self.error_label.config(text=str(self.connection_errors), foreground=error_color)
            
        except AttributeError:
            # GUI might not be fully initialized yet
            pass
    
    def on_left_click(self, event):
        """Handle left mouse click"""
        if not self.is_connected:
            return
        
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        request = {
            'type': 'mouse_click',
            'x': int(x),
            'y': int(y),
            'button': 'left'
        }
        self.send_request(request)
    
    def on_right_click(self, event):
        """Handle right mouse click"""
        if not self.is_connected:
            return
        
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        request = {
            'type': 'mouse_click',
            'x': int(x),
            'y': int(y),
            'button': 'right'
        }
        self.send_request(request)
    
    def on_double_click(self, event):
        """Handle double mouse click"""
        if not self.is_connected:
            return
        
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        request = {
            'type': 'mouse_click',
            'x': int(x),
            'y': int(y),
            'button': 'double'
        }
        self.send_request(request)
    
    def on_mouse_move(self, event):
        """Handle mouse movement"""
        if not self.is_connected:
            return
        
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        request = {
            'type': 'mouse_move',
            'x': int(x),
            'y': int(y)
        }
        self.send_request(request)
    
    def on_key_press(self, event):
        """Handle key press"""
        if not self.is_connected:
            return
        
        key = event.keysym
        
        # Map special keys
        key_mapping = {
            'Return': 'enter',
            'BackSpace': 'backspace',
            'Tab': 'tab',
            'Escape': 'esc',
            'space': 'space',
            'Up': 'up',
            'Down': 'down',
            'Left': 'left',
            'Right': 'right'
        }
        
        mapped_key = key_mapping.get(key, key.lower())
        
        request = {
            'type': 'key_press',
            'key': mapped_key
        }
        self.send_request(request)
    
    def send_file_to_host(self):
        """Send a file to the host"""
        if not self.is_connected:
            messagebox.showerror("Error", "Not connected to host")
            return
        
        try:
            file_path = filedialog.askopenfilename(
                title="Select file to send",
                filetypes=[("All files", "*.*")]
            )
            
            if file_path and os.path.exists(file_path):
                with open(file_path, 'rb') as f:
                    file_data = f.read()
                
                filename = os.path.basename(file_path)
                
                request = {
                    'type': 'file_transfer',
                    'transfer_type': 'send_file',
                    'filename': filename,
                    'file_size': len(file_data),
                    'file_data': base64.b64encode(file_data).decode('utf-8')
                }
                
                if self.send_request(request):
                    self.log_message(f"File sent: {filename}", self.transfer_log)
                else:
                    self.log_message(f"Failed to send file: {filename}", self.transfer_log)
                    
        except Exception as e:
            self.log_message(f"File send error: {str(e)}", self.transfer_log)
    
    def send_folder_to_host(self):
        """Send a folder to the host"""
        if not self.is_connected:
            messagebox.showerror("Error", "Not connected to host")
            return
        
        messagebox.showinfo("Feature", "Folder transfer feature will be implemented in a future update.")
    
    def request_file_from_host(self):
        """Request a file from the host"""
        if not self.is_connected:
            messagebox.showerror("Error", "Not connected to host")
            return
        
        try:
            request = {
                'type': 'file_transfer',
                'transfer_type': 'request_file'
            }
            
            if self.send_request(request):
                self.log_message("File request sent to host", self.transfer_log)
                
                # Handle response in a separate thread
                response_thread = threading.Thread(target=self.handle_file_response, daemon=True)
                response_thread.start()
            else:
                self.log_message("Failed to send file request", self.transfer_log)
                
        except Exception as e:
            self.log_message(f"File request error: {str(e)}", self.transfer_log)
    
    def receive_large_data_fast(self):
        """Receive large data with ULTRA-FAST optimizations"""
        try:
            # SPEED OPTIMIZATION: Shorter initial timeout
            self.client_socket.settimeout(10)  # Reduced from 15 to 10 seconds
            size_data = b""
            while len(size_data) < 4:
                chunk = self.client_socket.recv(4 - len(size_data))
                if not chunk:
                    return None
                size_data += chunk
            
            response_size = int.from_bytes(size_data, byteorder='big')
            
            # SPEED OPTIMIZATION: Dynamic timeout based on size
            if response_size > 1000000:  # 1MB
                self.client_socket.settimeout(45)  # Reduced from 60
            elif response_size > 500000:  # 500KB
                self.client_socket.settimeout(25)  # Reduced from 30
            else:
                self.client_socket.settimeout(10)  # Reduced from 15
            
            # SPEED OPTIMIZATION: Larger chunks for faster connections
            response_data = b""
            if self.bandwidth_score >= 3:  # Good connection
                chunk_size = 16384  # 16KB chunks
            elif self.bandwidth_score == 2:  # Medium connection
                chunk_size = 8192   # 8KB chunks
            else:  # Slow connection
                chunk_size = 4096   # 4KB chunks
            
            while len(response_data) < response_size:
                remaining = response_size - len(response_data)
                chunk = self.client_socket.recv(min(chunk_size, remaining))
                if not chunk:
                    break
                response_data += chunk
            
            if len(response_data) == response_size:
                self.connection_errors = max(0, self.connection_errors - 1)
                return response_data
            else:
                return None
                
        except socket.timeout:
            return None
        except Exception:
            return None
        finally:
            try:
                self.client_socket.settimeout(20)  # Reduced from 30
            except:
                pass
    
    def handle_connection_slowdown(self):
        """Handle connection slowdown with adaptive optimizations"""
        if self.connection_errors > 3:
            # Automatically reduce quality and increase refresh time
            old_quality = self.image_quality
            old_refresh = self.adaptive_refresh_rate
            
            self.image_quality = max(15, self.image_quality - 5)
            self.adaptive_refresh_rate = min(3.0, self.adaptive_refresh_rate * 1.2)
            
            # Also reduce image size for very slow connections
            if self.connection_errors > 5:
                if self.max_image_size[0] > 480:
                    self.max_image_size = (640, 480)
                    self.log_message("Connection very slow - reducing image size to 640x480")
                elif self.max_image_size[0] > 320:
                    self.max_image_size = (480, 360)
                    self.log_message("Connection extremely slow - reducing image size to 480x360")
            
            self.log_message(f"Adapting to slow connection: Quality {old_quality}→{self.image_quality}, Refresh {old_refresh:.1f}s→{self.adaptive_refresh_rate:.1f}s")
        
        # Update status indicators
        self.update_status_indicators()
    
    def handle_file_response(self):
        """Handle file transfer response from host"""
        try:
            # Receive response size
            size_data = self.client_socket.recv(4)
            if len(size_data) < 4:
                return
            
            response_size = int.from_bytes(size_data, byteorder='big')
            
            # Receive response data
            response_data = b""
            while len(response_data) < response_size:
                chunk = self.client_socket.recv(min(4096, response_size - len(response_data)))
                if not chunk:
                    break
                response_data += chunk
            
            if len(response_data) == response_size:
                response = json.loads(response_data.decode('utf-8'))
                
                if response.get('type') == 'file_transfer_response':
                    filename = response.get('filename', 'received_file')
                    file_data = base64.b64decode(response.get('file_data', ''))
                    
                    # Ask user where to save
                    save_path = filedialog.asksaveasfilename(
                        title="Save received file",
                        initialdir=os.path.expanduser("~/Downloads"),
                        initialfile=filename
                    )
                    
                    if save_path:
                        with open(save_path, 'wb') as f:
                            f.write(file_data)
                        self.log_message(f"File received and saved: {filename}", self.transfer_log)
                    else:
                        self.log_message("File save cancelled", self.transfer_log)
                        
        except Exception as e:
            self.log_message(f"File response handling error: {str(e)}", self.transfer_log)
    
    def toggle_fullscreen(self):
        """Toggle fullscreen mode for remote desktop viewing"""
        if not self.is_connected:
            messagebox.showerror("Error", "Not connected to host")
            return
            
        if self.is_fullscreen:
            self.exit_fullscreen()
        else:
            self.enter_fullscreen()
    
    def enter_fullscreen(self):
        """Enter fullscreen mode"""
        try:
            # Store original window size
            self.original_window_size = self.root.geometry()
            
            # Create fullscreen window
            self.fullscreen_window = tk.Toplevel(self.root)
            self.fullscreen_window.title("Remote Desktop - Fullscreen")
            
            # Make it fullscreen
            self.fullscreen_window.attributes("-fullscreen", True)
            self.fullscreen_window.configure(bg="black")
            
            # Create canvas for fullscreen display
            self.fullscreen_canvas = tk.Canvas(self.fullscreen_window, bg="black", highlightthickness=0)
            self.fullscreen_canvas.pack(fill=tk.BOTH, expand=True)
            
            # Bind events for fullscreen canvas
            self.fullscreen_canvas.bind("<Button-1>", self.on_fullscreen_left_click)
            self.fullscreen_canvas.bind("<Button-3>", self.on_fullscreen_right_click)
            self.fullscreen_canvas.bind("<Double-Button-1>", self.on_fullscreen_double_click)
            self.fullscreen_canvas.bind("<Motion>", self.on_fullscreen_mouse_move)
            self.fullscreen_canvas.bind("<KeyPress>", self.on_fullscreen_key_press)
            
            # Bind escape key to exit fullscreen
            self.fullscreen_window.bind("<Escape>", lambda e: self.exit_fullscreen())
            self.fullscreen_canvas.focus_set()
            
            # Update button text
            self.fullscreen_button.config(text="⛉ Exit Fullscreen")
            self.is_fullscreen = True
            
            # Copy current remote screen to fullscreen if available
            if self.remote_screen:
                self.display_fullscreen_image()
                
            self.log_message("Entered fullscreen mode - Press ESC to exit")
            
        except Exception as e:
            self.log_message(f"Fullscreen entry error: {str(e)}")
    
    def exit_fullscreen(self):
        """Exit fullscreen mode"""
        try:
            if self.fullscreen_window:
                self.fullscreen_window.destroy()
                self.fullscreen_window = None
                self.fullscreen_canvas = None
                self.fullscreen_remote_screen = None
            
            self.is_fullscreen = False
            self.fullscreen_button.config(text="⛶ Fullscreen")
            
            self.log_message("Exited fullscreen mode")
            
        except Exception as e:
            self.log_message(f"Fullscreen exit error: {str(e)}")
    
    def display_fullscreen_image(self):
        """Display the current remote screen image in fullscreen mode"""
        if not self.is_fullscreen or not self.fullscreen_canvas or not self.remote_screen:
            return
            
        try:
            # Get fullscreen dimensions
            screen_width = self.fullscreen_window.winfo_screenwidth()
            screen_height = self.fullscreen_window.winfo_screenheight()
            
            # Get original image from the regular canvas image
            if hasattr(self, 'remote_screen') and self.remote_screen:
                # Get the PIL image from the PhotoImage
                # We need to recreate it from the base64 data or scale the existing one
                
                # For now, let's create a scaled version of the current image
                # This is a simplified approach - in a full implementation, you'd want to
                # request a higher resolution image from the host for fullscreen
                
                # Get current image size
                canvas_width = self.canvas.winfo_width()
                canvas_height = self.canvas.winfo_height()
                
                if canvas_width > 1 and canvas_height > 1:  # Valid dimensions
                    # Calculate scaling to fit fullscreen while maintaining aspect ratio
                    scale_x = screen_width / canvas_width
                    scale_y = screen_height / canvas_height
                    scale = min(scale_x, scale_y)
                    
                    # Calculate new size
                    new_width = int(canvas_width * scale)
                    new_height = int(canvas_height * scale)
                    
                    # Center the image
                    x_offset = (screen_width - new_width) // 2
                    y_offset = (screen_height - new_height) // 2
                    
                    # Create scaled image
                    # For fullscreen, we'll just copy the current remote_screen
                    # In a full implementation, you'd request a high-res image from the host
                    self.fullscreen_canvas.delete("all")
                    self.fullscreen_canvas.create_image(x_offset, y_offset, anchor=tk.NW, image=self.remote_screen)
                    
                    # Store reference
                    self.fullscreen_remote_screen = self.remote_screen
                    
        except Exception as e:
            self.log_message(f"Fullscreen display error: {str(e)}")
    
    def on_fullscreen_left_click(self, event):
        """Handle left click in fullscreen mode"""
        self.handle_fullscreen_click(event, 'left')
    
    def on_fullscreen_right_click(self, event):
        """Handle right click in fullscreen mode"""
        self.handle_fullscreen_click(event, 'right')
    
    def on_fullscreen_double_click(self, event):
        """Handle double click in fullscreen mode"""
        self.handle_fullscreen_click(event, 'double')
    
    def handle_fullscreen_click(self, event, button_type):
        """Handle mouse clicks in fullscreen mode with coordinate mapping"""
        if not self.is_connected:
            return
            
        try:
            # Get fullscreen dimensions
            screen_width = self.fullscreen_window.winfo_screenwidth()
            screen_height = self.fullscreen_window.winfo_screenheight()
            
            # Get canvas dimensions for scaling
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width > 1 and canvas_height > 1:  # Valid dimensions
                # Calculate scaling that was used for display
                scale_x = screen_width / canvas_width
                scale_y = screen_height / canvas_height
                scale = min(scale_x, scale_y)
                
                # Calculate offset that was used for centering
                display_width = int(canvas_width * scale)
                display_height = int(canvas_height * scale)
                x_offset = (screen_width - display_width) // 2
                y_offset = (screen_height - display_height) // 2
                
                # Convert fullscreen coordinates back to original canvas coordinates
                adjusted_x = event.x - x_offset
                adjusted_y = event.y - y_offset
                
                # Scale back to original canvas size
                if scale > 0:
                    original_x = int(adjusted_x / scale)
                    original_y = int(adjusted_y / scale)
                    
                    # Make sure coordinates are within bounds
                    original_x = max(0, min(original_x, canvas_width))
                    original_y = max(0, min(original_y, canvas_height))
                    
                    # Send click request
                    request = {
                        'type': 'mouse_click',
                        'x': original_x,
                        'y': original_y,
                        'button': button_type
                    }
                    self.send_request(request)
                    
        except Exception as e:
            self.log_message(f"Fullscreen click error: {str(e)}")
    
    def on_fullscreen_mouse_move(self, event):
        """Handle mouse movement in fullscreen mode"""
        if not self.is_connected:
            return
            
        try:
            # Get fullscreen dimensions
            screen_width = self.fullscreen_window.winfo_screenwidth()
            screen_height = self.fullscreen_window.winfo_screenheight()
            
            # Get canvas dimensions for scaling
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width > 1 and canvas_height > 1:  # Valid dimensions
                # Calculate scaling that was used for display
                scale_x = screen_width / canvas_width
                scale_y = screen_height / canvas_height
                scale = min(scale_x, scale_y)
                
                # Calculate offset that was used for centering
                display_width = int(canvas_width * scale)
                display_height = int(canvas_height * scale)
                x_offset = (screen_width - display_width) // 2
                y_offset = (screen_height - display_height) // 2
                
                # Convert fullscreen coordinates back to original canvas coordinates
                adjusted_x = event.x - x_offset
                adjusted_y = event.y - y_offset
                
                # Scale back to original canvas size
                if scale > 0:
                    original_x = int(adjusted_x / scale)
                    original_y = int(adjusted_y / scale)
                    
                    # Make sure coordinates are within bounds
                    original_x = max(0, min(original_x, canvas_width))
                    original_y = max(0, min(original_y, canvas_height))
                    
                    # Send mouse move request
                    request = {
                        'type': 'mouse_move',
                        'x': original_x,
                        'y': original_y
                    }
                    self.send_request(request)
                    
        except Exception as e:
            self.log_message(f"Fullscreen mouse move error: {str(e)}")
    
    def on_fullscreen_key_press(self, event):
        """Handle key press in fullscreen mode"""
        # Handle escape key to exit fullscreen
        if event.keysym == 'Escape':
            self.exit_fullscreen()
            return
            
        # For all other keys, use the same logic as regular mode
        self.on_key_press(event)
    
    def run(self):
        """Start the client application"""
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except KeyboardInterrupt:
            self.disconnect_from_host()
    
    def on_closing(self):
        """Handle application closing"""
        if self.is_connected:
            self.disconnect_from_host()
        self.root.destroy()

if __name__ == "__main__":
    # Check if required modules are installed
    required_modules = ['PIL', 'socket', 'tkinter']
    missing_modules = []
    
    for module in required_modules:
        try:
            if module == 'PIL':
                import PIL
            else:
                exec(f"import {module}")
        except ImportError:
            missing_modules.append(module)
    
    if missing_modules:
        print(f"Missing required modules: {missing_modules}")
        print("Please install them using:")
        for module in missing_modules:
            if module == 'PIL':
                print("pip install Pillow")
            else:
                print(f"pip install {module}")
        input("Press Enter to exit...")
    else:
        app = RemoteDesktopClient()
        app.run()
