"""
Remote Desktop Host Application
Allows authorized remote connections with user permission prompts
"""

import socket
import threading
import tkinter as tk
from tkinter import messagebox, filedialog, ttk
import json
import os
import subprocess
import time
from PIL import Image, ImageTk
import io
import base64
import win32gui
import win32con
import win32api
import win32clipboard
from pynput import mouse, keyboard
from pynput.mouse import Button, Listener as MouseListener
from pynput.keyboard import Key, Listener as KeyboardListener
import pyautogui
import hashlib

class RemoteDesktopHost:
    def __init__(self):
        self.server_socket = None
        self.client_socket = None
        self.is_connected = False
        self.is_authorized = False
        self.client_username = ""
        self.server_running = False
        
        # Setup GUI
        self.setup_gui()
        
        # Default settings
        self.host_port = 9999
        self.host_ip = self.get_local_ip()
        
    def setup_gui(self):
        """Initialize the host GUI"""
        self.root = tk.Tk()
        self.root.title("Remote Desktop Host")
        self.root.geometry("400x500")
        self.root.resizable(False, False)
        
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Status section
        ttk.Label(main_frame, text="Host Status:", font=("Arial", 12, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 10))
        
        self.status_label = ttk.Label(main_frame, text="Not Running", foreground="red")
        self.status_label.grid(row=1, column=0, columnspan=2, pady=(0, 10))
        
        # IP section
        ttk.Label(main_frame, text="Your IP Address:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.ip_var = tk.StringVar(value=self.get_local_ip())
        ttk.Entry(main_frame, textvariable=self.ip_var, state="readonly", width=25).grid(row=2, column=1, pady=2)
        
        # Control buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        
        self.start_button = ttk.Button(button_frame, text="Start Host", command=self.start_server)
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = ttk.Button(button_frame, text="Stop Host", command=self.stop_server, state="disabled")
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        # Connection info
        ttk.Label(main_frame, text="Connection Info:", font=("Arial", 10, "bold")).grid(row=5, column=0, columnspan=2, pady=(20, 5))
        
        self.connection_info = tk.Text(main_frame, height=8, width=45, state="disabled")
        self.connection_info.grid(row=6, column=0, columnspan=2, pady=5)
        
        # Scrollbar for connection info
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.connection_info.yview)
        scrollbar.grid(row=6, column=2, sticky=(tk.N, tk.S))
        self.connection_info.configure(yscrollcommand=scrollbar.set)
        
        # Settings
        settings_frame = ttk.LabelFrame(main_frame, text="Settings", padding="5")
        settings_frame.grid(row=7, column=0, columnspan=2, pady=20, sticky=(tk.W, tk.E))
        
        self.auto_accept_var = tk.BooleanVar()
        ttk.Checkbutton(settings_frame, text="Auto-accept connections (Not recommended)", 
                       variable=self.auto_accept_var).grid(row=0, column=0, sticky=tk.W)
        
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            # Connect to Google DNS to get local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def log_message(self, message):
        """Add a message to the connection info log"""
        self.connection_info.config(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        self.connection_info.insert(tk.END, f"[{timestamp}] {message}\n")
        self.connection_info.see(tk.END)
        self.connection_info.config(state="disabled")
    
    def start_server(self):
        """Start the host server"""
        try:
            # Use fixed port 9999
            self.host_port = 9999
                
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', self.host_port))
            self.server_socket.listen(1)
            
            self.server_running = True
            self.status_label.config(text="Running - Waiting for connections", foreground="green")
            self.start_button.config(state="disabled")
            self.stop_button.config(state="normal")
            
            self.log_message(f"Server started on {self.ip_var.get()}:{self.host_port}")
            self.log_message("Waiting for incoming connections...")
            
            # Start server thread
            server_thread = threading.Thread(target=self.accept_connections, daemon=True)
            server_thread.start()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start server: {str(e)}")
    
    def stop_server(self):
        """Stop the host server"""
        self.server_running = False
        self.is_connected = False
        self.is_authorized = False
        
        if self.client_socket:
            try:
                self.client_socket.close()
            except:
                pass
            self.client_socket = None
            
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
            self.server_socket = None
        
        self.status_label.config(text="Not Running", foreground="red")
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        self.log_message("Server stopped")
    
    def accept_connections(self):
        """Accept incoming connections"""
        while self.server_running:
            try:
                client_socket, client_address = self.server_socket.accept()
                self.log_message(f"Connection attempt from {client_address[0]}")
                
                # Handle the connection in a separate thread
                connection_thread = threading.Thread(
                    target=self.handle_connection, 
                    args=(client_socket, client_address),
                    daemon=True
                )
                connection_thread.start()
                
            except socket.error:
                if self.server_running:
                    self.log_message("Socket error occurred")
                break
    
    def handle_connection(self, client_socket, client_address):
        """Handle a client connection"""
        try:
            # Receive connection request
            data = client_socket.recv(1024).decode('utf-8')
            connection_request = json.loads(data)
            
            if connection_request.get('type') == 'connection_request':
                username = connection_request.get('username', 'Unknown User')
                self.client_username = username
                
                # Ask for permission
                if self.auto_accept_var.get() or self.ask_permission(username):
                    self.log_message(f"Connection authorized for {username}")
                    self.client_socket = client_socket
                    self.is_connected = True
                    self.is_authorized = True
                    
                    # Send authorization response
                    response = {'type': 'connection_response', 'authorized': True}
                    client_socket.send(json.dumps(response).encode('utf-8'))
                    
                    # Update status
                    self.status_label.config(text=f"Connected to {username}", foreground="blue")
                    
                    # Start handling client requests
                    self.handle_client_requests(client_socket)
                    
                else:
                    self.log_message(f"Connection denied for {username}")
                    response = {'type': 'connection_response', 'authorized': False}
                    client_socket.send(json.dumps(response).encode('utf-8'))
                    client_socket.close()
                    
        except Exception as e:
            self.log_message(f"Connection handling error: {str(e)}")
            try:
                client_socket.close()
            except:
                pass
    
    def ask_permission(self, username):
        """Ask the user for permission to allow the connection"""
        result = messagebox.askyesno(
            "Connection Request",
            f"Would You Like To Let '{username}' Connect?",
            icon="question"
        )
        return result
    
    def handle_client_requests(self, client_socket):
        """Handle requests from the connected client"""
        try:
            while self.is_connected and self.server_running:
                data = client_socket.recv(4096)
                if not data:
                    break
                
                try:
                    request = json.loads(data.decode('utf-8'))
                    self.process_client_request(request, client_socket)
                except json.JSONDecodeError:
                    # Handle binary data or large requests differently
                    continue
                    
        except Exception as e:
            self.log_message(f"Client request handling error: {str(e)}")
        finally:
            self.disconnect_client()
    
    def process_client_request(self, request, client_socket):
        """Process different types of client requests"""
        request_type = request.get('type')
        
        if request_type == 'screenshot':
            self.send_screenshot(client_socket, request)
        elif request_type == 'ping':
            # Handle ping for connection speed testing
            response = {'type': 'pong', 'timestamp': time.time()}
            response_json = json.dumps(response)
            client_socket.send(len(response_json).to_bytes(4, byteorder='big'))
            client_socket.send(response_json.encode('utf-8'))
        elif request_type == 'mouse_click':
            self.handle_mouse_click(request)
        elif request_type == 'mouse_move':
            self.handle_mouse_move(request)
        elif request_type == 'key_press':
            self.handle_key_press(request)
        elif request_type == 'file_transfer':
            self.handle_file_transfer(request, client_socket)
    
    def send_screenshot(self, client_socket, request=None):
        """Capture and send screenshot to client with optimizations"""
        try:
            # Get quality and size settings from request
            quality = 40 if not request else request.get('quality', 40)
            max_size = (800, 600) if not request else request.get('max_size', (800, 600))
            
            # SPEED OPTIMIZATION: Fast screenshot capture
            screenshot = pyautogui.screenshot()
            
            # SPEED OPTIMIZATION: Differential update - only send if changed significantly
            current_hash = hashlib.md5(screenshot.tobytes()).hexdigest()
            if hasattr(self, '_last_screenshot_hash') and self._last_screenshot_hash == current_hash:
                # Send minimal "no change" response
                response = {
                    'type': 'screenshot_response',
                    'no_change': True
                }
                response_json = json.dumps(response)
                client_socket.send(len(response_json).to_bytes(4, byteorder='big'))
                client_socket.send(response_json.encode('utf-8'))
                return
            
            self._last_screenshot_hash = current_hash
            
            # SPEED OPTIMIZATION: Aggressive resizing for better performance
            if screenshot.size[0] > max_size[0] or screenshot.size[1] > max_size[1]:
                # Use faster resizing method
                screenshot.thumbnail(max_size, Image.Resampling.NEAREST)
            
            # SPEED OPTIMIZATION: Dynamic quality based on image complexity
            img_buffer = io.BytesIO()
            
            # Try ultra-fast compression first
            if quality <= 30:
                # For very low quality, use fastest settings
                screenshot.save(img_buffer, format='JPEG', quality=quality, optimize=False)
            else:
                # For higher quality, use optimize but keep it fast
                screenshot.save(img_buffer, format='JPEG', quality=quality, optimize=True)
            
            img_data = img_buffer.getvalue()
            
            # SPEED OPTIMIZATION: Check if we should compress further
            if len(img_data) > 100000:  # If larger than 100KB, compress more
                img_buffer = io.BytesIO()
                screenshot.save(img_buffer, format='JPEG', quality=max(15, quality-10), optimize=True)
                img_data = img_buffer.getvalue()
            
            # Send screenshot data with size info
            response = {
                'type': 'screenshot_response',
                'image_data': base64.b64encode(img_data).decode('utf-8'),
                'original_size': screenshot.size,
                'compressed_size': len(img_data)
            }
            
            response_json = json.dumps(response)
            
            # SPEED OPTIMIZATION: Send size first, then data in optimized chunks
            client_socket.send(len(response_json).to_bytes(4, byteorder='big'))
            
            # Send data in optimal chunks for speed
            chunk_size = 8192  # 8KB chunks for optimal speed
            response_bytes = response_json.encode('utf-8')
            
            for i in range(0, len(response_bytes), chunk_size):
                chunk = response_bytes[i:i + chunk_size]
                client_socket.send(chunk)
            
        except Exception as e:
            self.log_message(f"Screenshot error: {str(e)}")
    
    def handle_mouse_click(self, request):
        """Handle mouse click from client"""
        try:
            x = request.get('x', 0)
            y = request.get('y', 0)
            button = request.get('button', 'left')
            
            # Scale coordinates to actual screen size
            screen_width, screen_height = pyautogui.size()
            scaled_x = int(x * screen_width / 800)
            scaled_y = int(y * screen_height / 600)
            
            if button == 'left':
                pyautogui.click(scaled_x, scaled_y)
            elif button == 'right':
                pyautogui.rightClick(scaled_x, scaled_y)
            elif button == 'double':
                pyautogui.doubleClick(scaled_x, scaled_y)
                
        except Exception as e:
            self.log_message(f"Mouse click error: {str(e)}")
    
    def handle_mouse_move(self, request):
        """Handle mouse movement from client"""
        try:
            x = request.get('x', 0)
            y = request.get('y', 0)
            
            # Scale coordinates to actual screen size
            screen_width, screen_height = pyautogui.size()
            scaled_x = int(x * screen_width / 800)
            scaled_y = int(y * screen_height / 600)
            
            pyautogui.moveTo(scaled_x, scaled_y)
            
        except Exception as e:
            self.log_message(f"Mouse move error: {str(e)}")
    
    def handle_key_press(self, request):
        """Handle keyboard input from client"""
        try:
            key = request.get('key')
            if key:
                pyautogui.press(key)
                
        except Exception as e:
            self.log_message(f"Key press error: {str(e)}")
    
    def handle_file_transfer(self, request, client_socket):
        """Handle file transfer requests"""
        try:
            transfer_type = request.get('transfer_type')
            
            if transfer_type == 'send_file':
                # Client wants to send a file to host
                self.receive_file_from_client(request, client_socket)
            elif transfer_type == 'request_file':
                # Client requests a file from host
                self.send_file_to_client(request, client_socket)
                
        except Exception as e:
            self.log_message(f"File transfer error: {str(e)}")
    
    def receive_file_from_client(self, request, client_socket):
        """Receive a file from the client"""
        try:
            filename = request.get('filename', 'received_file')
            file_size = request.get('file_size', 0)
            file_data_b64 = request.get('file_data', '')
            
            # Decode file data
            file_data = base64.b64decode(file_data_b64)
            
            # Scan for viruses before accepting
            if self.scan_for_viruses(file_data, filename):
                # Ask user permission
                result = messagebox.askyesno(
                    "Virus Detected",
                    f"This File/Folder '{filename}' has a virus. Would You Still Like To Receive It?",
                    icon="warning"
                )
                
                if not result:
                    self.log_message(f"File transfer cancelled due to virus: {filename}")
                    return
            
            # Save the file
            save_path = filedialog.asksaveasfilename(
                title="Save received file",
                initialdir=os.path.expanduser("~/Downloads"),
                initialfile=filename
            )
            
            if save_path:
                with open(save_path, 'wb') as f:
                    f.write(file_data)
                self.log_message(f"File received and saved: {filename}")
            else:
                self.log_message(f"File transfer cancelled by user: {filename}")
                
        except Exception as e:
            self.log_message(f"File receive error: {str(e)}")
    
    def send_file_to_client(self, request, client_socket):
        """Send a file to the client"""
        try:
            file_path = filedialog.askopenfilename(
                title="Select file to send",
                filetypes=[("All files", "*.*")]
            )
            
            if file_path and os.path.exists(file_path):
                with open(file_path, 'rb') as f:
                    file_data = f.read()
                
                filename = os.path.basename(file_path)
                
                response = {
                    'type': 'file_transfer_response',
                    'filename': filename,
                    'file_size': len(file_data),
                    'file_data': base64.b64encode(file_data).decode('utf-8')
                }
                
                response_json = json.dumps(response)
                client_socket.send(len(response_json).to_bytes(4, byteorder='big'))
                client_socket.send(response_json.encode('utf-8'))
                
                self.log_message(f"File sent: {filename}")
                
        except Exception as e:
            self.log_message(f"File send error: {str(e)}")
    
    def scan_for_viruses(self, file_data, filename):
        """Basic virus scanning using Windows Defender"""
        try:
            # Create temporary file for scanning
            temp_path = os.path.join(os.environ['TEMP'], f"temp_scan_{filename}")
            
            with open(temp_path, 'wb') as temp_file:
                temp_file.write(file_data)
            
            # Use Windows Defender command line scanner
            result = subprocess.run([
                'powershell', '-Command',
                f"Get-MpThreatDetection | Where-Object {{$_.Resources -like '*{temp_path}*'}}"
            ], capture_output=True, text=True, timeout=10)
            
            # Clean up temp file
            try:
                os.remove(temp_path)
            except:
                pass
            
            # If there's output, it likely means a threat was detected
            return len(result.stdout.strip()) > 0
            
        except Exception as e:
            self.log_message(f"Virus scan error: {str(e)}")
            # If scanning fails, assume it's potentially dangerous
            return True
    
    def disconnect_client(self):
        """Disconnect the current client"""
        self.is_connected = False
        self.is_authorized = False
        
        if self.client_socket:
            try:
                self.client_socket.close()
            except:
                pass
            self.client_socket = None
        
        self.status_label.config(text="Running - Waiting for connections", foreground="green")
        self.log_message(f"Client {self.client_username} disconnected")
        self.client_username = ""
    
    def run(self):
        """Start the host application"""
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except KeyboardInterrupt:
            self.stop_server()
    
    def on_closing(self):
        """Handle application closing"""
        if self.server_running:
            self.stop_server()
        self.root.destroy()

if __name__ == "__main__":
    # Check if required modules are installed
    required_modules = ['PIL', 'pyautogui', 'pynput', 'win32gui']
    missing_modules = []
    
    for module in required_modules:
        try:
            if module == 'PIL':
                import PIL
            elif module == 'win32gui':
                import win32gui
            else:
                exec(f"import {module}")
        except ImportError:
            missing_modules.append(module)
    
    if missing_modules:
        print(f"Missing required modules: {missing_modules}")
        print("Please install them using:")
        for module in missing_modules:
            if module == 'PIL':
                print("pip install Pillow")
            elif module == 'win32gui':
                print("pip install pywin32")
            else:
                print(f"pip install {module}")
        input("Press Enter to exit...")
    else:
        app = RemoteDesktopHost()
        app.run()
