#!/usr/bin/env python3
"""
Simple test to check if screen refresh is working
"""

import time
import sys

try:
    from PIL import Image, ImageTk
    import pyautogui
    import tkinter as tk
    from tkinter import ttk
    import io
    import base64
except ImportError as e:
    print(f"Missing required module: {e}")
    print("Please install: pip install Pillow pyautogui")
    input("Press Enter to exit...")
    sys.exit(1)

class ScreenRefreshTest:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Screen Refresh Test")
        self.root.geometry("850x650")
        
        # Control frame
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(control_frame, text="Take Screenshot", command=self.take_screenshot).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Start Auto Refresh", command=self.start_auto_refresh).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Stop Auto Refresh", command=self.stop_auto_refresh).pack(side=tk.LEFT, padx=5)
        
        # Display frame
        self.canvas = tk.Canvas(self.root, bg="gray", width=800, height=600)
        self.canvas.pack(padx=10, pady=5)
        
        self.auto_refresh_running = False
        self.current_image = None
        
        print("Screen Refresh Test Ready!")
        print("Click 'Take Screenshot' to test single capture")
        print("Click 'Start Auto Refresh' to test continuous refresh")
        
    def take_screenshot(self):
        """Take a single screenshot"""
        try:
            print("Taking screenshot...")
            
            # Disable pyautogui failsafe
            pyautogui.FAILSAFE = False
            
            # Take screenshot
            screenshot = pyautogui.screenshot()
            print(f"Screenshot taken: {screenshot.size}")
            
            # Resize
            screenshot = screenshot.resize((800, 600), Image.Resampling.LANCZOS)
            print("Screenshot resized to 800x600")
            
            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(screenshot)
            
            # Display
            self.canvas.delete("all")
            self.canvas.create_image(0, 0, anchor=tk.NW, image=photo)
            
            # Keep reference
            self.current_image = photo
            
            print("✅ Screenshot displayed successfully!")
            
        except Exception as e:
            print(f"❌ Screenshot error: {e}")
            import traceback
            traceback.print_exc()
    
    def start_auto_refresh(self):
        """Start automatic refresh"""
        if not self.auto_refresh_running:
            self.auto_refresh_running = True
            print("🚀 Starting auto-refresh...")
            self.auto_refresh_loop()
    
    def stop_auto_refresh(self):
        """Stop automatic refresh"""
        self.auto_refresh_running = False
        print("🛑 Auto-refresh stopped")
    
    def auto_refresh_loop(self):
        """Auto refresh loop"""
        if not self.auto_refresh_running:
            return
        
        try:
            self.take_screenshot()
            
            # Schedule next refresh
            self.root.after(50, self.auto_refresh_loop)  # 20 FPS
            
        except Exception as e:
            print(f"❌ Auto-refresh error: {e}")
            self.auto_refresh_running = False
    
    def run(self):
        try:
            self.root.mainloop()
        except KeyboardInterrupt:
            print("Test interrupted")

if __name__ == "__main__":
    test = ScreenRefreshTest()
    test.run()
