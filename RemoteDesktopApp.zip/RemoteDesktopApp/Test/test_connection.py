"""
Simple test script to check network connectivity
"""
import socket
import time

def test_host_connection():
    """Test if we can connect to the host on port 9999"""
    print("Testing connection to localhost:9999...")
    
    try:
        # Try to connect to localhost on port 9999
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)  # 5 second timeout
        result = sock.connect_ex(('127.0.0.1', 9999))
        sock.close()
        
        if result == 0:
            print("✅ SUCCESS: Port 9999 is open and accepting connections")
            return True
        else:
            print("❌ FAILED: Cannot connect to port 9999")
            print(f"Error code: {result}")
            return False
            
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        return False

def check_port_availability():
    """Check if port 9999 is available"""
    print("Checking if port 9999 is available...")
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 9999))
        sock.close()
        print("✅ Port 9999 is available")
        return True
    except socket.error as e:
        if e.errno == 10048:  # Address already in use
            print("✅ Port 9999 is in use (this is good if host is running)")
            return False
        else:
            print(f"❌ Port issue: {str(e)}")
            return False

if __name__ == "__main__":
    print("=== Network Connection Test ===\n")
    
    print("1. Checking port availability:")
    port_available = check_port_availability()
    print()
    
    print("2. Testing connection:")
    connection_works = test_host_connection()
    print()
    
    if connection_works:
        print("🎉 Everything looks good! You should be able to connect.")
    elif not port_available:
        print("⚠️  Port 9999 is in use. Make sure the host app is running and click 'Start Host'.")
    else:
        print("❌ Connection failed. The host may not be running properly.")
        
    print("\n=== Instructions ===")
    print("1. Make sure the host app is running")
    print("2. In the host app, click 'Start Host' button")
    print("3. Use IP address: 127.0.0.1 (for localhost)")
    print("4. Try connecting with the client app")
    
    input("Press Enter to exit...")
