"""
Host Application Startup Helper
This will help you start the host application properly
"""
import subprocess
import sys
import time
import socket

def check_python_path():
    """Check if we can find the Python executable"""
    python_paths = [
        r"C:\Users\{}\AppData\Local\Programs\Python\Python313\python.exe".format(os.environ.get('USERNAME', 'Unknown')),
        "python.exe",
        "python3.exe",
        "py.exe"
    ]
    
    for path in python_paths:
        try:
            result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                print(f"✅ Found Python: {path}")
                return path
        except:
            continue
    
    print("❌ Could not find Python executable")
    return None

def main():
    print("=" * 50)
    print("🖥️  REMOTE DESKTOP HOST STARTUP HELPER")
    print("=" * 50)
    print()
    
    # Check if host_app.py exists
    import os
    if not os.path.exists("host_app.py"):
        print("❌ Error: host_app.py not found in current directory")
        print("Make sure you're running this from the RemoteDesktopApp folder")
        input("Press Enter to exit...")
        return
    
    print("📋 INSTRUCTIONS:")
    print("1. This will start the host application")
    print("2. In the host app window, click 'Start Host' button")
    print("3. Note the IP address shown in the host app")
    print("4. Start the client app and use that IP address")
    print("5. For localhost testing, use: 127.0.0.1")
    print()
    
    # Find Python
    python_exe = check_python_path()
    if not python_exe:
        print("Please install Python or check your installation")
        input("Press Enter to exit...")
        return
    
    print("🚀 Starting host application...")
    print("⚠️  IMPORTANT: Make sure to click 'Start Host' in the GUI!")
    print()
    
    try:
        # Start the host application
        subprocess.Popen([python_exe, "host_app.py"], cwd=os.getcwd())
        print("✅ Host application started!")
        print()
        print("👆 Look for the host application window")
        print("👆 Click 'Start Host' button in that window")
        print()
        print("🧪 Testing connection in 5 seconds...")
        
        # Wait a bit for the GUI to load
        for i in range(5, 0, -1):
            print(f"⏱️  {i}...", end="\r")
            time.sleep(1)
        print("      ", end="\r")  # Clear the countdown
        
        # Test connection
        print("🧪 Testing connection to localhost:9999...")
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('127.0.0.1', 9999))
        sock.close()
        
        if result == 0:
            print("🎉 SUCCESS! Host is running and accepting connections!")
            print("✅ You can now start the client app and connect using 127.0.0.1")
        else:
            print("⚠️  Host app is running but not listening on port 9999")
            print("👆 Make sure to click 'Start Host' button in the host app window")
            print("🔄 Try running this test again after clicking 'Start Host'")
            
    except Exception as e:
        print(f"❌ Error starting host application: {e}")
    
    print()
    input("Press Enter to exit...")

if __name__ == "__main__":
    import os
    main()
